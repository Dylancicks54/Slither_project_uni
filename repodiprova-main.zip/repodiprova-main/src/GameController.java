import java.awt.*;
import java.awt.event.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class GameController implements Serializable {
    private static final long serialVersionUID = 1L;
    private GameState gameState;
    private List<Player> players;
    private List<Bot> bots;
    private List<Food> foodItems;
    private List<Entity> entities;

    public GameController(GameState gameState){
        this.gameState = gameState;
        this.players = gameState.getPlayers();
        this.bots = gameState.getBots();
        this.foodItems = gameState.getFoodItems();
        this.entities = gameState.getEntities();
    }
    public void applyGameState(GameState state) {
        // Aggiorna i giocatori
        List<Player> updatedPlayers = new ArrayList<>();
        for (Player updatedPlayer : state.getPlayers()) {
            updatedPlayers.add(new Player(updatedPlayer.getId())); // Copia l'oggetto
        }
        players = updatedPlayers;  // Assegna la nuova lista

        // Aggiorna i bot
        List<Bot> updatedBots = new ArrayList<>();
        for (Bot updatedBot : state.getBots()) {
            updatedBots.add(new Bot(updatedBot.getPosition(), entities, state)); // Copia l'oggetto
        }
        bots = updatedBots;

        // Aggiorna il cibo
        List<Food> updatedFood = new ArrayList<>();
        for (Food updated : state.getFoodItems()) {
            updatedFood.add(new Food(updated.getPosition(), 10)); // Copia l'oggetto
        }
        foodItems = updatedFood;
    }

//    public void applyGameState(GameState state) {
//        for (Player player : players) {
//            Player updatedPlayer = state.getPlayerById(player.getId());
//            if (updatedPlayer != null) {
//                player.setPosition(updatedPlayer.getPosition());
//            }
//        }
//        for (Bot bot : bots) {
//            for (Bot updatedBot : state.getBots()) {
//                if (bot.equals(updatedBot)) {
//                    bot.setPosition(updatedBot.getPosition());
//                    break;
//                }
//            }
//        }
//        for (Food food : foodItems) {
//            for (Food updatedFood : state.getFoodItems()) {
//                if (food.equals(updatedFood)) {
//                    food.setPosition(updatedFood.getPosition());
//                    break;
//                }
//            }
//        }
//    }

    public void updateGameState() {
        gameState.updateGameState();
    }

    public List<Food> getFoodItems() {
        return foodItems;
    }

    public List<Bot> getBots() {
        return bots;
    }

    public List<Player> getPlayers() {
        return players;
    }


}
